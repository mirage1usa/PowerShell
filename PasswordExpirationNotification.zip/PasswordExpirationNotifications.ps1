#################################################################################################################
#
# Password-Expiration-Notifications v20180412
# Highly Modified fork. https://gist.github.com/meoso/3488ef8e9c77d2beccfd921f991faa64
#
# Originally from v1.4 @ https://gallery.technet.microsoft.com/Password-Expiry-Email-177c3e27
# Robert Pearman (WSSMB MVP)
# TitleRequired.com
# Script to Automated Email Reminders when Users Passwords due to Expire.
#
# Requires: Windows PowerShell Module for Active Directory
#
##################################################################################################################
# Please Configure the following variables....
$SearchBase = "OU=ACCOUNTS,DC=DOMAIN,DC=COM" # Active Directory OU structure to target
$smtpServer = "server name"	# Your mail relay server name
$domain = "Domain name"	# Domain name for use in email subject and body
$prewarning = 14 		#number of days to warn users the first time, set to zero to disable
$expireindays = 10 		#number of days of soon-to-expire paswords. i.e. notify for expiring in X days (and every day until $negativedays)
$negativedays = -1 		#negative number of days (days already-expired). i.e. notify for expired X days ago
$fromaddress = "Display Name <address@domain.com>" # Display Name and Email Address that email shows from
$imagepath1 = "C:\SCRIPTS\ScheduledTasks\PasswordExpirationEmails\Brand.jpg" # Uncomment to add an image to messages
#$imagepath2 = "C:\scripts\ScheduledTasks\PasswordExpirationEmails\IT.png" # Uncomment to add a 2nd image to messages
$logging = $true   		# Set to $false to Disable Logging
$logNonExpiring = $true	# Set to $false to only log expiring accounts
$logFile = "C:\SCRIPTS\ScheduledTasks\PasswordExpirationEmails\PS-pwd-expiry-$domain.csv" # ie. c:\mylog.csv
$testing = $false 		# Set to $false to Email Users
$adminEmailAddr = "IT.Notifications@domain.com" # Email address to send expiration log reports to. Multiple addresses allowed but MUST be independent quoted strings separated by comma
$sampleEmails = 0  		#number of sample email to send to adminEmailAddr when testing ; in the form $sampleEmails="ALL" or $sampleEmails=[0..X] e.g. $sampleEmails=0 or $sampleEmails=3 or $sampleEmails="all" are all valid.
#
###################################################################################################################

# System Settings
$textEncoding = [System.Text.Encoding]::UTF8
$date = Get-Date -format yyyy-MM-dd

$starttime=Get-Date #need time also; don't use date from above

Write-Host "Processing `"$SearchBase`" for Password-Expiration-Notifications" -foregroundcolor Green

#set max sampleEmails to send to $adminEmailAddr
if ( $sampleEmails -isNot [int]) {
    if ( $sampleEmails.ToLower() -eq "all") {
    $sampleEmails=$users.Count
    } #else use the value given
}

if (($testing -eq $true) -and ($sampleEmails -gt 0)) {
    Write-Host "TESTING only: $sampleEmails email samples will be sent to $adminEmailAddr" -foregroundcolor Yellow
} elseif (($testing -eq $true) -and ($sampleEmails -eq 0)) {
    Write-Host "TESTING only: emails will NOT be sent" -foregroundcolor Yellow
}

# Create CSV Log
if ($logging -eq $true) {
    #Always purge old CSV file
    Out-File $logfile
    Add-Content $logfile "`"Date`",`"SAMAccountName`",`"DisplayName`",`"Created`",`"PasswordSet`",`"DaystoExpire`",`"ExpiresOn`",`"enabled`",`"EmailAddress`",`"Notified`""
	Write-Host "LOGGING: Enabled - log file will be sent to $adminEmailAddr" -foregroundcolor Yellow
}

# Get Users From AD who are Enabled, Passwords Expire
Import-Module ActiveDirectory

$users = get-aduser -SearchBase $SearchBase -Filter {(enabled -eq $true) -and (passwordNeverExpires -eq $false)} -properties sAMAccountName, displayName, PasswordNeverExpires, PasswordExpired, PasswordLastSet, EmailAddress, lastLogon, whenCreated
$DefaultmaxPasswordAge = (Get-ADDefaultDomainPasswordPolicy).MaxPasswordAge

$countprocessed=${users}.Count
$samplesSent=0
$countsent=0
$countnotsent=0
$countfailed=0

# Process Each User for Password Expiry
foreach ($user in $users) {
	$fName = $user.givenname
    $dName = $user.displayName
    $sName = $user.sAMAccountName
    $emailaddress = $user.emailaddress
    $whencreated = $user.whencreated
	$enabled = $user.enabled
    $passwordSetDate = $user.PasswordLastSet
    $sent = "" # Reset Sent Flag

    $PasswordPol = (Get-AduserResultantPasswordPolicy $user)
    # Check for Fine Grained Password
    if (($PasswordPol) -ne $null) {
        $maxPasswordAge = ($PasswordPol).MaxPasswordAge
    } else {
        # No FGPP set to Domain Default
        $maxPasswordAge = $DefaultmaxPasswordAge
    }

    #If maxPasswordAge=0 then same as passwordNeverExpires, but PasswordCannotExpire bit is not set
    if ($maxPasswordAge -eq 0) {
        Write-Host "$sName MaxPasswordAge = $maxPasswordAge (i.e. PasswordNeverExpires) but bit not set."
    }

    $expiresOn = $passwordsetdate + $maxPasswordAge
    $today = (get-date)

    if ( ($user.passwordexpired -eq $false) -and ($maxPasswordAge -ne 0) ) {   #not Expired and not PasswordNeverExpires
		$daystoexpire = (New-TimeSpan -Start $today -End $expiresOn).Days
    } elseif ( ($user.passwordexpired -eq $true) -and ($passwordSetDate -ne $null) -and ($maxPasswordAge -ne 0) ) {   #if expired and passwordSetDate exists and not PasswordNeverExpires
        # i.e. already expired
    	$daystoexpire = -((New-TimeSpan -Start $expiresOn -End $today).Days)
    } else {
        # i.e. (passwordSetDate = never) OR (maxPasswordAge = 0)
    	$daystoexpire="NA"
        #continue #"continue" would skip user, but bypass any non-expiry logging
    }

    # Write-Host "$sName DtE: $daystoexpire MPA: $maxPasswordAge" # debug line

    # Determine if we process extra code to notify the user
    if (($emailaddress -ne "") -or ($emailaddress -ne $null)) {
		if (($daystoexpire -le $expireindays) -or ($prewarning -eq $daystoexpire)) {
			$notifyuser = $true
		} else {
			$notifyuser = $false
		}
	}

    # Process mail steps only if needed
    if ($notifyuser) {
        # Set English verbiage based on Number of Days to Expiry.
        Switch ($daystoexpire) {
            {$_ -ge $negativedays -and $_ -le "-1"} {$messageDaysEnglish = "has expired"}
            "0" {$messageDaysEnglish = "will expire today"}
            "1" {$messageDaysEnglish = "will expire in 1 day"}
            default {$messageDaysEnglish = "will expire in " + "$daystoexpire" + " days"}
        }
        # Set Spanish verbiage based on Number of Days to Expiry.
        Switch ($daystoexpire) {
            {$_ -ge $negativedays -and $_ -le "-1"} {$messageDaysSpanish = "ha expirado"}
            "0" {$messageDaysSpanish = "caducara hoy"}
            "1" {$messageDaysSpanish = "caducara en 1 dia"}
            default {$messageDaysSpanish = "caducara en " + "$daystoexpire" + " dias"}
        }
        # Set French verbiage based on Number of Days to Expiry.
        Switch ($daystoexpire) {
            {$_ -ge $negativedays -and $_ -le "-1"} {$messageDaysFrench = "a expire"}
            "0" {$messageDaysFrench = "expirera aujourd`'hui"}
            "1" {$messageDaysFrench = "expirera dans 1 jour"}
            default {$messageDaysFrench = "expirera dans " + "$daystoexpire" + " jours"}
        }

        # Email Subject Set Here
        if ($testing -eq $true) {
        	$subject="IMPORTANT: Your $domain password $messageDaysEnglish TEST"
        } else {
	        $subject="IMPORTANT: Your $domain password $messageDaysEnglish"
        }

        # Email Body Set Here, Note You can use HTML, including Images. <p><img src=cid:att1 /></p> is for the brand logo
        $body="
        <p><img src=cid:att1 /></p>
        <p>Hello  $fName,</p>
        <p>
        <b>ACCOUNT:  $sName</b><br>
        <b>DAYS TO EXPIRATION:  $daystoexpire</b>
        </p>
        <p>The password for your $domain account $messageDaysEnglish.  After expiration, you will not be able to login until your password is changed.</p>
        <p>Please visit <b>myaccount.microsoft.com</b> to change your password.</p>
		<hr>
		<p>La contrase&ntilde;a de su cuenta de $domain $messageDaysSpanish. Despu&eacute;s del vencimiento, no podr&aacute; iniciar sesi&oacute;n hasta que cambie su contrase&ntilde;a.</p>
        <p>Visite <b>myaccount.microsoft.com</b> para cambiar su contrase&ntilde;a.</p>
        <hr>
		<p>Votre mot de passe $domain compte $messageDaysFrench. Apr&egrave;s cette p&eacute;riode, vous ne pourrez plus vous connecter tant que celui-ci n`'aura pas &eacute;t&eacute; modifi&eacute;.</p>
		<p>Veuillez visiter <b>myaccount.microsoft.com</b> pour le modifier.</p>
		<hr>
		<p>
		   <b><a href='https://'>Password Requirements Document (Nortek)</a></b></p>
        <p>Thank you,<br>
           IT Support</br>
		</p>
        "

        # If testing-enabled and send-samples, then set recipient to adminEmailAddr else user's EmailAddress
        if (($testing -eq $true) -and ($samplesSent -lt $sampleEmails)) {
            $recipient = $adminEmailAddr
        } else {
            if ($emailaddress -eq $null) {
				$recipient = "BLANK@address.com"
			} else {
				$recipient = $emailaddress
			}
        }


        # Prepare email
        Add-PSSnapin Microsoft.Exchange.Management.Powershell.Admin -erroraction silentlyContinue
		# Debug Line
        write-host "Data check: $sName : $emailaddress : $daystoexpire : $prewarning : $samplesSent : $sampleEmails : $recipient"		
        $SendTo = $recipient
        $Image1 = $ImagePath1								# Uncomment if adding an image to messages
        $att1 = new-object Net.Mail.Attachment($Image1)		# Uncomment if adding an image to messages
        $att1.ContentId = "att1"							# Uncomment if adding an image to messages
        #$Image2 = $ImagePath2								# Uncomment if adding 2nd image to messages
        #$att2 = new-object Net.Mail.Attachment($Image2)	# Uncomment if adding 2nd image to messages
        #$att2.ContentId = "att2"							# Uncomment if adding 2nd image to messages
        $Message = new-object Net.Mail.MailMessage
        $smtp = new-object Net.Mail.SmtpClient($smtpServer)
        $Message.From = $fromaddress
        $Message.To.Add($SendTo)
        $Message.Subject = $subject
        $Message.Body = $body
        $Message.IsBodyHTML = $true
		$Message.Priority = 2 # high priority tag
        $Message.Attachments.Add($att1)
        #$Message.Attachments.Add($att2)
    
        # WARNING EMAIL - if in trigger range, send warning email
        if ( ($prewarning -eq $daystoexpire) ) {
            # Send Email Message
            if (($emailaddress) -ne $null) {
                if ( ($testing -eq $false) -or (($testing -eq $true) -and ($samplesSent -lt $sampleEmails)) ) {
                    try {
                        $smtp.Send($Message)
                        $att1.Dispose()
                        #$att2.Dispose()
                    } catch {
                        write-host "Error: Could not send email to $recipient via $smtpServer"
                        $sent = "Send Fail"
                        $countfailed++
                    } finally {
                        if ($err.Count -eq 0) {
                            write-host "Sent $prewarning day warning email for $sName to $recipient"
                            $countsent++
                            if ($testing -eq $true) {
                                $samplesSent++
                                $sent = "toAdmin"
                            } else { $sent = "NOTIFIED" }
                        }
                    }
                } else {
                    Write-Host "Testing mode: skipping email to $recipient"
                    $sent = "Testing-NotSent"
                    $countnotsent++
                }
            } else {
                Write-Host "NOEMAILADDR: $dName ($sName)"
                $sent = "NoAddress"
                $countnotsent++
            }
        }

       # ALERT EMAIL - if in trigger range, send email
        if ( ($daystoexpire -ge $negativedays) -and ($daystoexpire -le $expireindays) -and ($daystoexpire -ne "NA") ) {
            # Send Email Message
            if (($emailaddress) -ne $null) {
                if ( ($testing -eq $false) -or (($testing -eq $true) -and ($samplesSent -lt $sampleEmails)) ) {
                    try {
                        $smtp.Send($Message)
                        $att1.Dispose()
                        #$att2.Dispose()
                    } catch {
                        write-host "Error: Could not send email to $recipient via $smtpServer"
                        $sent = "Send Fail"
                        $countfailed++
                    } finally {
                        if ($err.Count -eq 0) {
                            write-host "Sent email: for $sName to $recipient"
                            $countsent++
                            if ($testing -eq $true) {
                                $samplesSent++
                                $sent = "toAdmin"
                            } else { $sent = "Yes" }
                        }
                    }
                } else {
                    Write-Host "Testing mode: skipping email to $recipient"
                    $sent = "Testing-NotSent"
                    $countnotsent++
                }
            } else {
                Write-Host "NOEMAILADDR: $dName ($sName)"
                $sent = "Expired & NO ADDRESS"
                $countnotsent++
            }
        }
		if ($daystoexpire -lt $negativedays) {
            if ($emailaddress -ne $null) {
		        if ($maxPasswordAge -eq 0) {
                    $sent = "NeverExp"
                } else {
                    $sent = "Expired"
				}
            } else {
				$sent = "Expired & No Address"
			}
		}
		# If Logging is Enabled Log Details
        if (($logging -eq $true) -and ($notifyuser -eq $true)) {
            Add-Content $logfile "`"$date`",`"$sName`",`"$dName`",`"$whencreated`",`"$passwordSetDate`",`"$daystoExpire`",`"$expireson`",`"enabled`",`"$emailaddress`",`"$sent`""
        }
	}

    # If Logging Non-Expired is Enabled Log Non-Expiring Password
    if (($logging -eq $true) -and ($logNonExpiring -eq $true) -and ($notifyuser -eq $false)) {
        if ($emailaddress -ne $null) {
		    if ($maxPasswordAge -eq 0 ) {
                $sent = "NeverExp"
            } else {
                $sent = "Not Expiring"
            }
			if ($daystoexpire -le 0) {
				$sent = "Expired"
			}
	    } else {
		    if ($maxPasswordAge -eq 0 ) {
                $sent = "NeverExp & NoAddress"
            } else {
                $sent = "No Address"
            }
        }
    Add-Content $logfile "`"$date`",`"$sName`",`"$dName`",`"$whencreated`",`"$passwordSetDate`",`"$daystoExpire`",`"$expireson`",`"enabled`",`"$emailaddress`",`"$sent`""
    }
	
$notifyuser = $false   
$sent = ""

} # End User Processing

$endtime=Get-Date
$totaltime=($endtime-$starttime).TotalSeconds
$minutes="{0:N0}" -f ($totaltime/60)
$seconds="{0:N0}" -f ($totaltime%60)

Write-Host "$countprocessed Users from `"$SearchBase`" Processed in $minutes minutes $seconds seconds."
Write-Host "Email trigger range from $negativedays (past) to $expireindays (upcoming) days of user's password expiry date."
Write-Host "$countsent Emails Sent."
Write-Host "$countnotsent Emails skipped."
Write-Host "$countfailed Emails failed."

if ($logging -eq $true) {
    #sort the CSV file
    Rename-Item $logfile "$logfile.old"
    import-csv "$logfile.old" | sort ExpiresOn | export-csv $logfile -NoTypeInformation
    Remove-Item "$logFile.old"
    Write-Host "CSV File created at ${logfile}."

    #email the CSV and stats to admin(s) 
    if ($testing -eq $true) {
        $body="<b><i>Testing Mode.</i></b><br>"
    } else {
        $body=""
    }

    $body+="
    CSV Attached for $date<br>
    $countprocessed Users from `"$SearchBase`" Processed in $minutes minutes $seconds seconds.<br>
    Email trigger range from $negativedays (past) to $expireindays (upcoming) days of user's password expiry date.<br>
    $countsent Emails Sent.<br>
    $countnotsent Emails skipped.<br>
    $countfailed Emails failed.
    "

    try {
        Send-Mailmessage -smtpServer $smtpServer -from $fromaddress -to $adminEmailAddr -subject "Password Expiry Logs" -body $body -port 25 -bodyasHTML -Attachments "$logFile" -priority High -Encoding $textEncoding -ErrorAction Stop -ErrorVariable err
    } catch {
        write-host "Error: Failed to email CSV log to $adminEmailAddr via $smtpServer."
        write-host "Error is: $err"
    } finally {
        if ($err.Count -eq 0) {
            write-host "CSV emailed to $adminEmailAddr"
        }
    }
}
write-host ""
# End