#################################################################################################################
#
# Password-Expiration-Notifications v20180412
# Highly Modified fork. https://gist.github.com/meoso/3488ef8e9c77d2beccfd921f991faa64
#
# Originally from v1.4 @ https://gallery.technet.microsoft.com/Password-Expiry-Email-177c3e27
# Robert Pearman (WSSMB MVP)
# TitleRequired.com
# Script to Automated Email Reminders when Users Passwords due to Expire.
#
# Requires: Windows PowerShell Module for Active Directory
#
##################################################################################################################
# Please Configure the following variables....
$smtpServer = "Your mail relay server name"
$domain = "Domain name for use in email subject and body"
$fromaddress = "Display Name <address@domain.com>"
$imagepath1 = "C:\SCRIPTS\ScheduledTasks\PasswordExpirationEmails\Brand.jpg"
$testemailaddress = "TEST@email.com"
#
###################################################################################################################

# System Settings
$textEncoding = [System.Text.Encoding]::UTF8

# Get Users From AD who are Enabled, Passwords Expire
Import-Module ActiveDirectory

$subject="IMPORTANT: Your $domain password - TEST"

        # Email Body Set Here, Note You can use HTML, including Images.
        $body="
        <p><img src=cid:att1 /></p>
        <p>Hello,</p>
        <p>
        <b>ACCOUNT:  Test</b><br>
        <b>DAYS TO EXPIRATION:  Testing - not expiring</b>
        </p>
        <p>The password for your $domain account will expire.  After expiration, you will not be able to login until your password is changed.</p>
        <p>Please visit <b>myaccount.microsoft.com</b> to change your password.</p>
		<hr>
		<p>
		   <b><a href='https://'>Password Requirements Document (Nortek)</a></b></p>
        <p>Thank you,<br>
           IT Support</br>
		</p>
        "

    $recipient = $testemailaddress

        # Prepare email
        Add-PSSnapin Microsoft.Exchange.Management.Powershell.Admin -erroraction silentlyContinue
	
        $SendTo = $recipient
        $Image1 = $ImagePath1
        $att1 = new-object Net.Mail.Attachment($Image1)
        $att1.ContentId = "att1"
        #$Image2 = $ImagePath2
        #$att2 = new-object Net.Mail.Attachment($Image2)
        #$att2.ContentId = "att2"
        $Message = new-object Net.Mail.MailMessage
        $smtp = new-object Net.Mail.SmtpClient($smtpServer)
        $Message.From = $fromaddress
        $Message.To.Add($SendTo)
        $Message.Subject = $subject
        $Message.Body = $body
        $Message.IsBodyHTML = $true
		$Message.Priority = 2 # high priority tag
        $Message.Attachments.Add($att1)
        #$Message.Attachments.Add($att2)

# Send Test Email    
try {
    $smtp.Send($Message)
    $att1.Dispose()
    #$att2.Dispose()
} catch {
    write-host "Error: Could not send email to $recipient via $smtpServer"
}